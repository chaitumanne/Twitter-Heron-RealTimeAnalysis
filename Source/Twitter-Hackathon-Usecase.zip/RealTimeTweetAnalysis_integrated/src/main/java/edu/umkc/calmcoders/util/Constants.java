package edu.umkc.calmcoders.util;

public class Constants {
  public static final String SYSTEM_COMPONENT_ID = "__system";
  public static final String SYSTEM_TICK_STREAM_ID = "__tick";
}
